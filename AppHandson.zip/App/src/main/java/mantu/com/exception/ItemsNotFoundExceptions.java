package mantu.com.exception;

public class ItemsNotFoundExceptions extends RuntimeException {

	public ItemsNotFoundExceptions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemsNotFoundExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
