package mantu.com.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import mantu.com.exception.ItemsNotFoundExceptions;

@ControllerAdvice
public class ErrorHandler {
	@ExceptionHandler(ItemsNotFoundExceptions.class)
	public String handleError(ItemsNotFoundExceptions ex,RedirectAttributes attributes) {
		attributes.addFlashAttribute("message", ex.getMessage());
		return "redirect:/";
	}
	
}
