package mantu.com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import mantu.com.model.Items;
import mantu.com.service.ItemsService;
@Controller
public class ItemsController {
	@Autowired
	private ItemsService itemsService;
	@GetMapping("/")
	public String index(Model model) {
		List<Items> items=itemsService.getAll();
		model.addAttribute("items", items);
		return "index";
	}
	@GetMapping("/add")
	public String showAdd(Model model) {
		Items items=new Items();
		model.addAttribute("items", items);
		return "add";
	}
	@PostMapping("/add-items")
	public String addItems(@Valid Items items,BindingResult result) {
		if(result.hasErrors()) {
			return "add";
		}
		itemsService.addItems(items);
		return "redirect:/";
	}
	@GetMapping("/update")
	public String showUpdate(@RequestParam int id,Model model) {
		Items items=itemsService.getById(id);
		model.addAttribute("items", items);
		return "update";
	}
	@PostMapping("/update-items")
	public String updateItems(@Valid Items items,BindingResult result) {
		if (result.hasErrors()) {
			return "update";
		}
		itemsService.updateItems(items);
		return "redirect:/";
	}
	@GetMapping("/delete")
	public String deleteItems(@RequestParam int id) {
		itemsService.deleteItems(id);
		return "redirect:/";
	}
	@GetMapping("/search")
	public String detailsItems(HttpServletRequest request,Model model) {
		int id=Integer.parseInt(request.getParameter("Search"));
		Items items=itemsService.getById(id);
		model.addAttribute("items",items);
		return "details";
	}
	
}
