package mantu.com.service;

import java.util.List;

import mantu.com.model.Items;

public interface ItemsService {
	List<Items>getAll();
	Items getById(int id);
	Items addItems(Items items);
	Items updateItems(Items items);
	void deleteItems(int id);
}
