package mantu.com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mantu.com.exception.ItemsNotFoundExceptions;
import mantu.com.model.Items;
import mantu.com.repository.ItemsRepository;

@Service 
public class ItemsServiceImpl implements ItemsService {
	@Autowired
	private ItemsRepository repository;
	 
	@Override
	public List<Items> getAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Items getById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).orElseThrow(()->new ItemsNotFoundExceptions("Items not found"+id+"not found"));
	}

	@Override
	public Items addItems(Items items) {
		// TODO Auto-generated method stub
		return repository.save(items);
	}

	@Override
	public Items updateItems(Items items) {
		// TODO Auto-generated method stub
		
		return repository.save(items);
	}

	@Override
	public void deleteItems(int id) {
		repository.deleteById(id);

	}

}
