package mantu.com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mantu.com.entity.Supplier;
import mantu.com.repository.SupplierRepository;
@Service
public class SupplierServiceImpl implements SupplierService {
	@Autowired
	private SupplierRepository repository;
	
	@Override
	public List<Supplier> getAllSuppliers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Supplier getSupplier(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).orElseThrow(()->new RuntimeException("supplier id not found"));
	}

	@Override
	public Supplier addSupplier(Supplier supply) {
		// TODO Auto-generated method stub
		return repository.save(supply);
	}

	@Override
	public Supplier updateSupplier(int id, Supplier supply) {
		Supplier supplier=repository.findById(id).orElseThrow(()->new RuntimeException("supplier id not found"));
		if(supply.getSupplierName()!=null) {
			supplier.setSupplierName(supply.getSupplierName());
		}
		if(supply.getSupplierPlace()!=null) {
			supplier.setSupplierPlace(supply.getSupplierPlace());
		}
		return repository.save(supplier);
	}

	@Override
	public void deleteSupplier(int id) {
		repository.deleteById(id);

	}

}
