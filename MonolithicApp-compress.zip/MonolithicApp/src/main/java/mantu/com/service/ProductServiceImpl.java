package mantu.com.service;

import java.util.List;

import org.springframework.stereotype.Service;

import mantu.com.entity.Product;
import mantu.com.repository.ProductRepository;
@Service
public class ProductServiceImpl implements ProductService {
	
	private ProductRepository repository;
	public ProductServiceImpl(ProductRepository repository) {
		this.repository = repository;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Product getProducts(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).orElseThrow(()->new RuntimeException("product Not found"));
	}

	@Override
	public Product addProducts(Product product) {
		// TODO Auto-generated method stub
		return repository.save(product);
	}

	@Override
	public Product updateProducts(int id, Product product) {
		// TODO Auto-generated method stub
		Product pro= repository.findById(id).orElseThrow(()->new RuntimeException("product Not found"));
		if(product.getProductName()!=null) {
			pro.setProductName(product.getProductName());
		}
		if(product.getProductPrice()!=0) {
			pro.setProductPrice(product.getProductPrice());
		}
		return repository.save(pro);
	}

	@Override
	public void deleteProducts(int id) {
		repository.deleteById(id);

	}

}
