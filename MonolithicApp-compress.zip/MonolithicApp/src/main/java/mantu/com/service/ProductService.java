package mantu.com.service;

import java.util.List;

import mantu.com.entity.Product;

public interface ProductService {
	List<Product>getAllProducts();
	Product getProducts(int id);
	Product addProducts(Product product);
	Product updateProducts(int id,Product product);
	void deleteProducts(int id);
}
