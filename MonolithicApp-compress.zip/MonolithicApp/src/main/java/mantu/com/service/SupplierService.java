package mantu.com.service;

import java.util.List;

import mantu.com.entity.Supplier;

public interface SupplierService {
	List<Supplier>getAllSuppliers();
	Supplier getSupplier(int id);
	Supplier addSupplier(Supplier supply);
	Supplier updateSupplier(int id,Supplier supply);
	void deleteSupplier(int id);
	
}
