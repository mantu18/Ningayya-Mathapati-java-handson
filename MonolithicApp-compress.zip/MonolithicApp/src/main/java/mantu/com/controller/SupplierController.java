package mantu.com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mantu.com.entity.Supplier;
import mantu.com.service.SupplierServiceImpl;

@RestController
@RequestMapping("/api/supplier")
public class SupplierController {
	@Autowired
	private SupplierServiceImpl supplyService;
	
	@GetMapping
	public List<Supplier> getAllSupply(){
		return supplyService.getAllSuppliers();
	}
	@GetMapping("/{id}")
	public Supplier getSupplierId(@PathVariable int id) {
		return supplyService.getSupplier(id);
	}
	@PostMapping
	public Supplier createSupply(@RequestBody Supplier supply) {
		return supplyService.addSupplier(supply);
	}
	@PutMapping("/{id}")
	public Supplier updateSupply(@PathVariable int id,@RequestBody Supplier supply) {
		return supplyService.updateSupplier(id, supply);
	}
	@DeleteMapping("/{id}")
	public void deleteSupply(@PathVariable int id) {
		supplyService.deleteSupplier(id);
	}

}
