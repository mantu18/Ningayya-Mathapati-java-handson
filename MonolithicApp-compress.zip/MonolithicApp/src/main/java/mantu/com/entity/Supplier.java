package mantu.com.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Supplier {
	@Id
	private int supplierId;
	private String supplierName;
	private String supplierPlace;
	
	@ManyToOne
	@JoinColumn(name="prouctId")
	private Product product;

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierPlace() {
		return supplierPlace;
	}

	public void setSupplierPlace(String supplierPlace) {
		this.supplierPlace = supplierPlace;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Supplier(int supplierId, String supplierName, String supplierPlace, Product product) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.supplierPlace = supplierPlace;
		this.product = product;
	}
	public Supplier() {
		
	}
}
