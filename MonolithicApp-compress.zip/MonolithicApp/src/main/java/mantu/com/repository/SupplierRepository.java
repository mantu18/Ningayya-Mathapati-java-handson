package mantu.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mantu.com.entity.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier, Integer> {

}
