package mantu.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mantu.com.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

}
