package mantu.com.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class BootStrapConsumer {
	@KafkaListener(topics="demo-topic",groupId="my-group")
	public void consume(String message) {
		System.out.println("consumed message " + message); 
	}
}
