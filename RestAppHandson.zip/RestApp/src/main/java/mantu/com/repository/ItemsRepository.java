package mantu.com.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import mantu.com.entity.Items;

public interface ItemsRepository extends JpaRepository<Items, Integer> {

	List<Items> findByName(String name);

	List<Items> findByPriceGreaterThan(double price);

}
