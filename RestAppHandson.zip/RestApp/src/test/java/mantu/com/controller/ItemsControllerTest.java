package mantu.com.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import mantu.com.entity.Items;
import mantu.com.service.ItemsService;

@ExtendWith(MockitoExtension.class)
class ItemsControllerTest {

	@Mock
	private ItemsService itemsService;
	@InjectMocks
	private ItemsController itemsController;
	
	MockMvc mockMvc;
	ObjectMapper mapper=new ObjectMapper();
	@BeforeEach
	public void setUp() {
		mockMvc=MockMvcBuilders.standaloneSetup(itemsController).build();
	}
	@Test
	void testGetAll() throws Exception {
		List<Items> items=List.of(
				new Items(1,"Ball",50,4,"bowling"),
				new Items(2,"Bat",1000,5,"batting")
				
				);
		when(itemsService.getAllItems()).thenReturn(items);
		
		mockMvc.perform(get("/api/items").accept(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(status().isOk()).
		andExpect(jsonPath("$").exists()).
		andExpect(jsonPath("$.size()").value(2));

	}
	@Test
	void testGetById() throws Exception {
		int id=1;
		Items item=new Items(1,"pencil",20,5,"sketch");
		when(itemsService.getById(id)).thenReturn(item);
		mockMvc.perform(get("/api/items/{id}",id).accept(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(status().isOk()).
		andExpect(jsonPath("$.name").value("pencil"));
	}
	@Test
	void testAddItems() throws Exception{
		Items item=new Items(1,"TV",30000,2,"watching film");
		String itemJson=mapper.writeValueAsString(item);
		when(itemsService.addItems(any(Items.class))).thenReturn(item);
		mockMvc.perform(post("/api/items").content(itemJson).contentType(MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON_VALUE)).
		
		andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(status().isCreated()).
		andExpect(jsonPath("$").exists()).
		andExpect(jsonPath("$.name").value("TV"));
	}
	@Test
	void testUpdateItems() throws Exception{
		int id=1;
		Items item=new Items(1,"fan",4000,3,"air");
		String itemjson=mapper.writeValueAsString(item);
		when(itemsService.updateItems(anyInt(), any(Items.class))).thenReturn(item);
		mockMvc.perform(put("/api/items/{id}",id).content(itemjson).contentType(MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).
		andExpect(status().isOk());
		
	}
	@Test
	void testDeleteItems() throws Exception{
		int id=1;
		mockMvc.perform(delete("/api/items/{id}",id)).andExpect(status().isNoContent());
	}
	
}
