package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Datetests {
	DateTest date;
	
	@BeforeEach
	@Test
	void init() {
		date=new DateTest(04,07,2000);
	}

	@Test
	void getDay() {
		int day=date.getDay();
		assertEquals(04, day);
		
	}
	@Test
	void getMonth() {
		int month=date.getMonth();
		assertEquals(07, month);
		
	}
	@Test
	void getYear() {
		int year=date.getYear();
		assertEquals(2000, year);
		
	}
	
	

}
