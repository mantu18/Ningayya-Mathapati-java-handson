package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Testcase {
	Person person;
	
	@BeforeEach
	@Test
	void init() {
		person=new Person("mantu","virat");
	}
	@Test
	void getFullName() {
		String full=person.getFirstName() + person.getLastName();
		assertEquals("mantuvirat", full);
	}
	@Test 
	void firstName(){
		String first=person.getFirstName();
		assertEquals("mantu",first);
	}
	@Test
	void lastName() {
		String last=person.getLastName();
		assertEquals("virat", last);
	}

}
