package nin.com;

import java.util.List;
import java.util.stream.Collectors;

public class WithoutDepartment {
	public static void main(String[] args) {
		List<Employee> employee=Employee.createEmployee();
		List<Employee> employeesWithoutDepartment = employee.stream()
                .filter(e -> e.getDepartment() == null || e.getDepartment().isEmpty())
                .collect(Collectors.toList());
        System.out.println("Employees without department:");
        employeesWithoutDepartment.forEach(e ->
                System.out.println(e.getFirstName() + " " + e.getLastName()));
	}
	
	
}
