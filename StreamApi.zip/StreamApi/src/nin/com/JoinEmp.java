package nin.com;

import java.util.List;

public class JoinEmp {
	public static void main(String[] args) {
		List<Employee> employee=Employee.createEmployee();
		employee.forEach(e->System.out.println(e.getFirstName()+" "+e.getLastName()+" Hiredate "
				+e.getHireDate()+" day of week "+e.getDayOfWeekHired()));
	}
	
}
