package nin.com;

import java.time.LocalDate;
import java.time.Period;

import java.util.List;


public class Employee {
	private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private LocalDate hireDate;
    private String designation;
    private double salary;
    private int managerId;
    private String department;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Employee(int id, String firstName, String lastName, String email, String phoneNumber, LocalDate hireDate,
			String designation, double salary, int managerId, String department) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.hireDate = hireDate;
		this.designation = designation;
		this.salary = salary;
		this.managerId = managerId;
		this.department = department;
	}
	@Override
	public String toString() {
		return "Emplyoee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", phoneNumber=" + phoneNumber + ", hireDate=" + hireDate + ", designation=" + designation
				+ ", salary=" + salary + ", managerId=" + managerId + ", department=" + department + "]";
	}
    
    public static List<Employee> createEmployee(){
    	return List.of(new Employee(1, "Mantu", "M", "Mantu@gmail.com", "9829018920",
                LocalDate.of(2020, 5, 15), "Manager", 80000, 0, "IT"),
        new Employee(2, "Manu", "V", "Manu@gmail.com", "9278263733",
                LocalDate.of(2021, 8, 10), "Engineer", 60000, 1, "Engineering"),
        new Employee(3, "Omkar", "H", "omkar@gmail.com", "97828182282",
                LocalDate.of(2022, 3, 25), "Developer", 70000, 1, null),
        new Employee(4, "Pavan", "g", "pavan@gmail.com", "7890123456",
                LocalDate.of(2018, 9, 1), "Analyst", 75000, 2, "HR"),
        new Employee(5, "Sharan", "H", "Sharan@gmail.com.com", "8152829733",
                LocalDate.of(2022, 11, 20), "Consultant", 90000, 0, "Consulting"));
    };
    public static void main(String[] args) {
        List<Employee> employees = createEmployee();
        employees.forEach(e->System.out.println(e));
    }
	public String getServiceDuration() {
		Period period = Period.between(hireDate, LocalDate.now());
        return period.getYears() + " years, " + period.getMonths() + " months, " + period.getDays() + " days";
    }
	public String getDayOfWeekHired() {
		return hireDate.getDayOfWeek().toString();
	}
	public double getSalaryIncrement(double percent) {
		
		return salary*(1+ percent/100);
	}
}


