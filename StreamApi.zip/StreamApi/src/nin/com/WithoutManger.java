package nin.com;

import java.util.List;
import java.util.stream.Collectors;

public class WithoutManger {
	public static void main(String[] args) {
		List<Employee> employee=Employee.createEmployee();
		List<Employee> employeesWithoutManager = employee.stream()
                .filter(e -> e.getManagerId() == 0)
                .collect(Collectors.toList());
        System.out.println("Employees without a manager:");
        employeesWithoutManager.forEach(e ->
                System.out.println(e.getFirstName() + " " + e.getLastName()));
	}
	
	
}
