package nin.com;

import java.util.List;

public class StreamDateTotalSalary {
	public static void main(String[] args) {
		List<Employee> employee=Employee.createEmployee();
		employee.forEach(e->System.out.println(e));
		double totalSalary = employee.stream()
                .mapToDouble(Employee::getSalary)
                .sum();
        System.out.println("Total salary of all employees: " + totalSalary);

	}
}
