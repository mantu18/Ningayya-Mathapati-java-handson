package mantu.com.controller;

import java.net.URI;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mantu.com.model.Items;
import mantu.com.service.ItemsService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/items")
public class ItemsController {
	private ItemsService itemsService;

	public ItemsController(ItemsService itemsService) {
		this.itemsService = itemsService;
	}
	@GetMapping
	public Flux<Items>getAllItems(){
		return itemsService.getAllItems();
	}
	@GetMapping("/{id}")
	public Mono<Items>findById(@PathVariable int id){
		return itemsService.getItems(id);
	}
	@PostMapping
	public Mono<ResponseEntity<Items>>createItems(@RequestBody Items items){
		return itemsService.createItems(items).map(createdItems->ResponseEntity.created(URI.create("/items" +createdItems.getId())).body(createdItems));
	}
	@PutMapping("/{id}")
	public Mono<Items>updateItems(@PathVariable int id,@RequestBody Items items){
		return itemsService.updateItems(id, items);
	}
	@DeleteMapping("/{id}")
	public Mono<Void>deleteItems(@PathVariable int id){
		return itemsService.deleteItems(id);
	}
	
}
