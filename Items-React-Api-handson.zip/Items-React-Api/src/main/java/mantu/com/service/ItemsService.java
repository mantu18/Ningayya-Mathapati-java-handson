package mantu.com.service;


import mantu.com.model.Items;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ItemsService {
	Flux<Items>getAllItems();
	Mono<Items>getItems(int id);
	Mono<Items>createItems(Items items);
	Mono<Items>updateItems(int id,Items items);
	Mono<Void>deleteItems(int id);
	
}
