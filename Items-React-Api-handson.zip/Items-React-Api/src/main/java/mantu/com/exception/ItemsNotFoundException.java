package mantu.com.exception;

public class ItemsNotFoundException extends RuntimeException {

	public ItemsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
