package mantu.com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mantu.com.model.Stores;
import mantu.com.repository.StoreRepository;

@Service
public class StoreServiceImpl implements StoreService {
	@Autowired
	private StoreRepository storeRepository;
	@Override
	public List<Stores> findAll() {
		return storeRepository.findAll();
	}

	@Override
	public Stores findById(int id) {
		return storeRepository.findById(id).orElseThrow(()->new RuntimeException("id not found"));
	}

	@Override
	public Stores addStore(Stores store) {
		return storeRepository.save(store);
	}

	@Override
	public Stores updateStore(int id, Stores store) {
		Stores existingStore=storeRepository.findById(id).orElseThrow(()->new RuntimeException("id not found"));
		if(store.getName()!=null) {
			existingStore.setName(store.getName());
		}
		if(store.getPrice()!=0) {
			existingStore.setPrice(store.getPrice());
		}
		if(store.getQuantity()!=0) {
			existingStore.setQuantity(store.getQuantity());
		}
		return storeRepository.save(existingStore);
	}

	@Override
	public void deleteStores(int id) {
		storeRepository.deleteById(id);

	}

}
