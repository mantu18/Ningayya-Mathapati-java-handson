package mantu.com.service;

import java.util.List;

import mantu.com.model.Stores;

public interface StoreService {
	List<Stores>findAll();
	Stores findById(int id);
	Stores addStore(Stores store);
	Stores updateStore(int id,Stores store);
	void deleteStores(int id);
}
