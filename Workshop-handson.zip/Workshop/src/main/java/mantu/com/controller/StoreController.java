package mantu.com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import mantu.com.model.Stores;
import mantu.com.service.StoreService;

@RestController
@CrossOrigin
public class StoreController {
	@Autowired
	private StoreService storeService;
	
	@GetMapping
	public List<Stores> findAllStores() {
		return storeService.findAll();
	}
	@GetMapping("/{id}")
	public Stores findById(@PathVariable int id) {
		return storeService.findById(id);
	}
	@PostMapping
	public Stores addStore(@RequestBody Stores store) {
		return storeService.addStore(store);
	}
	@PutMapping("/{id}")
	public Stores updateStore(@PathVariable int id,@RequestBody Stores store) {
		return storeService.updateStore(id, store);
	}
	@DeleteMapping("/{id}")
	public void deleteStore(@PathVariable int id) {
		storeService.deleteStores(id);
	}
	
}
