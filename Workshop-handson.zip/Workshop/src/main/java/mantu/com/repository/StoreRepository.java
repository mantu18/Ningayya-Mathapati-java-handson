package mantu.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import mantu.com.model.Stores;

public interface StoreRepository extends JpaRepository<Stores, Integer> {

}
