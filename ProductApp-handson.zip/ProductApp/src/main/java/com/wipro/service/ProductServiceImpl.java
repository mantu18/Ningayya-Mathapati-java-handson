package com.wipro.service;

import java.util.List;

import com.wipro.model.Product;
import com.wipro.repository.ProductRepository;
import com.wipro.repository.ProductRepositoryImpl;

public class ProductServiceImpl implements ProductService {
	
	private ProductRepository repository=new ProductRepositoryImpl();

	@Override
	public List<Product> getAll() {
		// TODO Auto-generated method stub
		return repository.getAll();
	}

	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		return repository.addProduct(product);
	}

	@Override
	public void deleteProduct(int id) {
		repository.deleteProduct(id);
		
	}
}
