package com.wipro.service;

import java.util.List;

import com.wipro.model.Product;

public interface ProductService {
	List<Product> getAll();
	String addProduct(Product product);
	void deleteProduct(int id);
}
