package com.wipro.repository;

import java.util.List;


import org.hibernate.Session;

import com.wipro.model.Product;
import com.wipro.util.DbUtil;

import jakarta.persistence.TypedQuery;

public class ProductRepositoryImpl implements ProductRepository {
	private Session session=DbUtil.getSession();
	
	@Override
	public List<Product> getAll(){
		TypedQuery<Product> query=session.createQuery("from Product", Product.class);
		System.out.println("hello");
		return query.getResultList();
	}
	@Override
	public String addProduct(Product product){
		session.beginTransaction();
		session.persist(product);
		session.getTransaction().commit();
		return "Employee Saved Successfully";
	}
	@Override
	public void deleteProduct(int id) {
		
		Product product=session.find(Product.class, id);
		session.beginTransaction();
		session.remove(product);
		session.getTransaction().commit();	
	}
}
