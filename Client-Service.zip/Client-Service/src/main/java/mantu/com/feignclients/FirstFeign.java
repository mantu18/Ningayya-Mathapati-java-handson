package mantu.com.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="First-Client")
public interface FirstFeign {
	@GetMapping("/first")
	public String firstMessage();
}
