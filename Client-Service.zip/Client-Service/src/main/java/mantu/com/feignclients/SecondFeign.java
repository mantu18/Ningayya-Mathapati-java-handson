package mantu.com.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="Second-Client")
public interface SecondFeign {
	
	@GetMapping("/second")
	public String secondMessage();
}
