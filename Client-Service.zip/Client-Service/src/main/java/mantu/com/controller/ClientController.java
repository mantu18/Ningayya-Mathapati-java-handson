package mantu.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import mantu.com.feignclients.FirstFeign;
import mantu.com.feignclients.SecondFeign;

@RestController
public class ClientController {
	@Autowired
	private FirstFeign firstClient;
	@Autowired
	private SecondFeign secondClient;
	
	@GetMapping("/messages")
	public String getMessage() {
		String first=firstClient.firstMessage();
		String second=secondClient.secondMessage();
		return first+"-"+second;
	}
	
}
