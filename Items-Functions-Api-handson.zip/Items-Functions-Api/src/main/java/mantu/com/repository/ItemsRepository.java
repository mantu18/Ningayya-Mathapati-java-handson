package mantu.com.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import mantu.com.model.Items;

public interface ItemsRepository extends ReactiveCrudRepository<Items, Integer> {

}
