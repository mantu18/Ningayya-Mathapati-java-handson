package mantu.com.router;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RequestPredicates.*;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import mantu.com.handler.ItemsHandler;

@Configuration
public class RouteConfig {
	@Bean
	RouterFunction<ServerResponse> routes(ItemsHandler itemshandler){
		return RouterFunctions.nest(path("/api/items"),
				route(GET(""),itemshandler::getAllItems)
				.andRoute(POST(""),itemshandler::createItems)
                .andRoute(GET("/{id}"),itemshandler::getById)
                .andRoute(PUT("/{id}"),itemshandler::updateItems)
                .andRoute(DELETE("/{id}"),itemshandler::deleteItems)
				);
	}
}
