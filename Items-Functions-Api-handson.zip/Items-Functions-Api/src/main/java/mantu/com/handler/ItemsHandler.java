package mantu.com.handler;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import static org.springframework.web.reactive.function.server.ServerResponse.*;
import mantu.com.model.Items;
import mantu.com.service.ItemsService;
import reactor.core.publisher.Mono;
@Component
public class ItemsHandler {
	private ItemsService itemsService;

	public ItemsHandler(ItemsService itemsService) {
		this.itemsService = itemsService;
	}
	public Mono<ServerResponse>getAllItems(ServerRequest request){
		return ok().body(itemsService.getAllItems(),Items.class);
	}
	public Mono<ServerResponse>getById(ServerRequest request){
		int id=Integer.parseInt(request.pathVariable("id"));
		return ok().body(itemsService.itemById(id), Items.class);
	}
	public Mono<ServerResponse>createItems(ServerRequest request){
		return request.bodyToMono(Items.class).flatMap(itemsService::addItems).
				flatMap(item->created(request.uriBuilder().path("/{id}").build(item.getId())).bodyValue(item));
	}
	  public Mono<ServerResponse> updateItems(ServerRequest request) {
	        int id=Integer.parseInt(request.pathVariable("id"));
	        return request.bodyToMono(Items.class)
	                .flatMap(item->itemsService.updateItems(id,item))
	                .flatMap(e->ok().bodyValue(e));
	    }
	    public Mono<ServerResponse> deleteItems(ServerRequest request) {
	        int id=Integer.parseInt(request.pathVariable("id"));
	        return itemsService.deleteItems(id)
	                .then(noContent().build());
	    }
	
}
