package mantu.com.service;



import java.util.function.Function;
import org.springframework.stereotype.Service;

import mantu.com.model.Items;
import mantu.com.repository.ItemsRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Service
public class ItemsServiceImpl implements ItemsService {
	private ItemsRepository repositry;
	
	
	public ItemsServiceImpl(ItemsRepository repositry) {
		this.repositry = repositry;
	}

	@Override
	public Flux<Items> getAllItems() {
		// TODO Auto-generated method stub
		return repositry.findAll();
	}

	@Override
	public Mono<Items> itemById(int id) {
		// TODO Auto-generated method stub
		return repositry.findById(id).switchIfEmpty(Mono.error(new RuntimeException("Items Not Found")));
	}

	@Override
	public Mono<Items> addItems(Items items) {
		// TODO Auto-generated method stub
		return repositry.save(items);
	}

	@Override
	public Mono<Items> updateItems(int id, Items items) {
		Mono<Items>itemMono=repositry.findById(id).switchIfEmpty(Mono.error(new RuntimeException("Items Not Found")));
		var updatedItems=itemMono.map(item->{
			if(items.getName()!=null) {
				item.setName(items.getName());
			}
			if(items.getPrice()!=0) {
				item.setPrice(items.getPrice());
			}
			if(items.getQuantity()!=0) {
				item.setQuantity(items.getQuantity());
			}
			if(items.getDescription()!=null) {
				item.setDescription(items.getDescription());
			}
			return repositry.save(item);
		});
		return updatedItems.flatMap(Function.identity());
	}

	@Override
	public Mono<Void> deleteItems(int id) {
		repositry.findById(id).switchIfEmpty(Mono.error(new RuntimeException("Items Not Found")));
		return repositry.deleteById(id);
	}

}
