package mantu.com.service;

import mantu.com.model.Items;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ItemsService {
	Flux<Items>getAllItems();
	Mono<Items>itemById(int id);
	Mono<Items>addItems(Items items);
	Mono<Items>updateItems(int id,Items items);
	Mono<Void>deleteItems(int id);
}
