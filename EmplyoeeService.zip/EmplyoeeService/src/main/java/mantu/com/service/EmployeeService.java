package mantu.com.service;

import mantu.com.dtos.ApiResponseDto;
import mantu.com.dtos.EmployeeDto;

public interface EmployeeService {
	EmployeeDto saveEmployeeDto(EmployeeDto employeeDto);
	ApiResponseDto getEmployee(Long id);
}
