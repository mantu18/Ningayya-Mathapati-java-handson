package mantu.com.service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import mantu.com.clients.DepartmentClients;
import mantu.com.dtos.ApiResponseDto;
import mantu.com.dtos.DepartmentDto;
import mantu.com.dtos.EmployeeDto;
import mantu.com.entity.Employee;
import mantu.com.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	private DepartmentClients departmentClient;
	public EmployeeServiceImpl(DepartmentClients departmentClient) {
		this.departmentClient = departmentClient;
	}
	Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	@Override
	public EmployeeDto saveEmployeeDto(EmployeeDto employeeDto) {
		Employee employee = new Employee(employeeDto.getId(), employeeDto.getFirstName(), 
				employeeDto.getLastName(),
				employeeDto.getEmail(), employeeDto.getDepartmentCode());
		Employee savedEmployee = employeeRepository.save(employee);
		return new EmployeeDto(savedEmployee.getId(), savedEmployee.getFirstName(), 
				savedEmployee.getLastName(),
				savedEmployee.getEmail(), savedEmployee.getDepartmentCode());
	}
	@CircuitBreaker(name="${spring.application.name}" ,fallbackMethod="getDepartmentFallback")
	public ApiResponseDto getEmployee(Long id) {
		Employee employee = employeeRepository.findById(id).get();
		EmployeeDto employeeDto = new EmployeeDto(employee.getId(), 
				employee.getFirstName(), employee.getLastName(),
				employee.getEmail(), employee.getDepartmentCode());
		DepartmentDto departmentDto = departmentClient.
				getDepartmentByCode(employee.getDepartmentCode());
		return new ApiResponseDto(employeeDto, departmentDto);
	}
	public ApiResponseDto getDepartmentFallback(Long id,Exception ex) {
		logger.info("getDepartmentFallback method is called with id: "+id);
		Employee employee = employeeRepository.findById(id).get();
		EmployeeDto employeeDto = new EmployeeDto(employee.getId(), 
				employee.getFirstName(), employee.getLastName(),
				employee.getEmail(), employee.getDepartmentCode());
		DepartmentDto departmentDto = new DepartmentDto(
				null, "Department Not Found", "Department Not Found", "Department Not Found");
		return new ApiResponseDto(employeeDto, departmentDto);
	}
}

