package com.wipro.repository;

import java.util.List;

import com.wipro.model.Product;

public interface ProductRepository {
	List<Product> getAll();
	String addProduct(Product product);
	void deleteProduct(int id);
}
