package com.wipro.controller;
import com.wipro.service.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import com.wipro.model.Product;

/**
 * Servlet implementation class ProductServlet
 */
public class ProductServlet extends HttpServlet {
	
	private ProductService service=new ProductServiceImpl();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath();
		HttpSession session=request.getSession();
		
		
		if(path.equals("/product")) {
			
			List<Product> product=service.getAll();
			System.out.println(product);
			session.setAttribute("product", product);
			
			response.sendRedirect("index.jsp");
			
			
		}
		if(path.equals("/add")) {
			response.sendRedirect("add.jsp");
		}
		if(path.equals("/add-product")) {
			
			
			int id=Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			double price=Double.parseDouble("price");
			int quantity=Integer.parseInt(request.getParameter("quantity"));
			String description=request.getParameter("description");
			Product product=new Product(id,name,price,quantity,description);
			service.addProduct(product);
			response.sendRedirect("product");	
		}
		if(path.equals("/delete")) {
			int id=Integer.parseInt(request.getParameter("id"));
			service.deleteProduct(id);
			response.sendRedirect("product");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
