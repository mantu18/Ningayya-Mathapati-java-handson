package mantu.com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mantu.com.dtos.DepartmentDto;
import mantu.com.entity.Department;
import mantu.com.repository.DepartmentRepository;
@Service
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired
	private DepartmentRepository departmentRepository;
	@Override
	public DepartmentDto saveDepartment(DepartmentDto departmentDto) {
		Department department=new Department(
				departmentDto.getId(),
				departmentDto.getDepartmentName(),
				departmentDto.getDepartmentDescription(),
				departmentDto.getDepartmentCode()
				);
		Department savedDepartment=departmentRepository.save(department);
				
		return new DepartmentDto(savedDepartment.getId(), savedDepartment.getDepartmentName(), savedDepartment.getDepartmentDescription(), savedDepartment.getDepartmentCode());
	}

	@Override
	public DepartmentDto getDepartmentCode(String departmentCode) {
		Department department = departmentRepository.
				findByDepartmentCode(departmentCode);
		return new DepartmentDto(department.getId(), 
				department.getDepartmentName(),
				department.getDepartmentDescription(), 
				department.getDepartmentCode());
	}

}
