package mantu.com.service;

import mantu.com.dtos.DepartmentDto;

public interface DepartmentService {
	DepartmentDto saveDepartment(DepartmentDto departmentDto);
	DepartmentDto getDepartmentCode(String departmentCode);
}
