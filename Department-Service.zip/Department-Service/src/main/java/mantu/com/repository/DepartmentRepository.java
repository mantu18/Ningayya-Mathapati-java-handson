package mantu.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mantu.com.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
	Department findByDepartmentCode(String departmentCode);
}
